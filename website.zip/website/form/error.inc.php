<style type="text/css">
* {
    margin: 0;
    padding: 0;
    border: 0;
    box-sizing: border-box;
}
.menu {
        list-style: none;
        position: absolute;
        top: 1px;
        right: 10px;
        width: 80%;
        font-family: 'richardsonscript.otf';
        font-size: 40px;
        text-align: center;
}

.menu > ul > li {
        display: inline-block;
        background: black;
        width: 24%;
        margin-bottom: 1px;
        position: relative;
}
.menu ul li a{
        color: whitesmoke;
        display: block;
        padding: 10px;
        text-decoration: none;
}
.menu ul li a:hover {
        background: white;
        color: black;
        transition: .3s;
}
.sub-menu {
        display: none;
}
.menu-item:hover .sub-menu {
        display: block;
        position: absolute;
        top: 63px;
        background:black;
        width: 97%;
        font-family: sans-serif;
        font-size: 20px;
}

.container {
    padding-top: 200%;
}
</style>

<header>
<nav class="menu">
                <ul>
                    <li class="menu-item"><a href="index.html">Home</a></li>
                    <li class="menu-item"><a href="about.html">About</a></li>
                    <li class="menu-item"><a href="#">Services</a>
                    <ul class="sub-menu">
                        <li class="menu-item"><a href="schedule-call.html">Schedule Discovery Call</a></li>
                        <li class="menu-item"><a href="Webinar.html">Webinars</a></li>
                        <li class="menu-item"><a href="one-on-one-coaching.html">One-on-One Coaching</a></li>

                    </ul>
                    </li>
                    <li class="menu-item"><a href="Resources.html">Resources</a>
                    <ul class="sub-menu">
                        <li class="menu-item"><a href="blog.html">Blog</a></li>
                        <li class="menu-item"><a href="podcast.html">Podcast</a></li>
                        <li class="menu-item"><a href="favorites.html">My Favorites</a></li>

                    </ul>
                    </li>
                </ul>
            </nav>
</header>
<div class="container">
<h1>Missing fields</h1>
<p>Sorry, you have not completed all of the required fields.</p>
<p>Please hit <a href="#" onClick="history.go(-1)">back</a> and complete the following required fields.</p>
</div>
<ul>
<?php
	for($i=0; $i<count($this->missing_required_fields); $i++){
		echo "<li>" . $this->missing_required_fields[$i]['title'] . "</li>\n";
	}
?>
</ul>

<p><strong><a href="#" onClick="history.go(-1)">Back to form</a></strong></p>